@component('mail::message')


<p>You have been assigned a task. Please go and check it.</p>


Thanks,<br>
{{ config('app.name') }}
@endcomponent
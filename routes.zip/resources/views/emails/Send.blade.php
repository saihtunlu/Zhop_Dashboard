@component('mail::message')

{!! $message !!}

Thanks,<br>
{{ config('app.name') }}
@endcomponent
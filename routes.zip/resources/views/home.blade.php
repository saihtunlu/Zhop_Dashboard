@extends('layouts.app')

@section('content')
<div id="app" class="container-fluid">
    <App></App>
</div>
@endsection